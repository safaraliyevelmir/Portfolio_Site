// <!-- <script src="{% static js/particlar.js %}"></script> -->
// <!-- <script src="{% static 'js/pj.js' %}"></script>
// <script src="{% static 'css/bar.js' %}"></script> -->
// <!-- <link rel="stylesheet" href="{% static 'js/pj.js' %}">
// <link rel="stylesheet" href="{% static 'css/bar.js' %}"> --></link>